# HAPSEG
A probabilistic method to interpret bi-allelic marker data in cancer samples.
